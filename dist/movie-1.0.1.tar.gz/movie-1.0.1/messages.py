class Messages:
    INVALID_USERNAME_OR_PASSWORD={"code":1,"msg":"用户名或密码错误"}
    BAD_REQUEST={"code":2,"msg":"请求信息错误"}
    USER_EXISTS={"code":3,"msg":"用户名已存在"}
    NOT_FOUND={"code":4,"msg":"资源不存在"}
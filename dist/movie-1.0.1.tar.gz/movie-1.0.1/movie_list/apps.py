from django.apps import AppConfig


class MovieListConfig(AppConfig):
    name = 'movie_list'
